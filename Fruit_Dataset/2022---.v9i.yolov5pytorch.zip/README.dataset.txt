# 2022농진청 > 2022-08-27 10:06pm
https://universe.roboflow.com/object-detection/2022-icqj3

Provided by Roboflow
License: CC BY 4.0

